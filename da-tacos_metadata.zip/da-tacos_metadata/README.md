This folder contains the metadata for the files 
included in Da-TACOS dataset.

For more information and the instructions for
how to use the dataset, please visit our GitHub
repository.

https://github.com/MTG/da-tacos